import { combineReducers } from "redux";
import TaskReducer from './taskReducer'

export default combineReducers({
    TaskReducer
})